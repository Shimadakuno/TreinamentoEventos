/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package treinamentoLogica;
import java.io.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
 

/**
 *
 * @author Shimada
 */
public class Treinamento {
    //Classes globais
        private String Nome;
	private String Sobrenome;
        private String NomeCompleto;
	private String CafeNome;
        private Integer CafeLote;
        private String SalaNome;
        private Integer Lotacao;
        
	//Metodo de busca dos dados nos arquivos de texto
        public static String match(String pattern, String filePath) {
		try {
			FileReader reader = new FileReader(filePath);
			BufferedReader leitor = new BufferedReader(reader);
			String linha = "";
			
			while(true) {
				linha = leitor.readLine();
				if( linha == null ) {
					break;
				}
				if( linha.matches(pattern) ) {
                                    JOptionPane.showMessageDialog(null, "Nome informado foi encontrado");
					return linha;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
                JOptionPane.showMessageDialog(null, "Nome não encontrado");
		return "texto não encontrado";
	}
        //Metodos Get e set
	public String getNome() {
		return Nome;
	}
	
	public void setNome(String Nome){
		this.Nome = Nome;
	}
	
	public String getSobrenome() {
		return Sobrenome;
	}
	
	public void setSobrenome(String Sobrenome){
            this.Sobrenome = Sobrenome;
	}
        
        public String getNomeCompleto() {
            return NomeCompleto;
        }
        
        public void setNomeCompleto(String NomeCompleto) {
            this.NomeCompleto = NomeCompleto;
        }
        
	public void setSalaNome(String SalaNome){
		this.SalaNome = SalaNome;
	}
        
	public int getLotacao() {
		return Lotacao;
	}
	
	public void setLotacao(Integer Lotacao){
		this.Lotacao = Lotacao;
	}
	
	
	public String getCafeNome() {
		return CafeNome;
	}
	
	public void setCafeNome(String CafeNome){
		this.CafeNome = CafeNome;
	}
        
        public Integer getCafeLote() {
		return CafeLote;
	}
	
	public void setCafeLote(Integer CafeLote){
		this.CafeLote = CafeLote;
	}
        //Metodos para salvar informações nos arquivos de texto
	public String SalvarPessoa(){
		try{
                
		File txt = new File("CadastroPessoa.txt");
		FileWriter fw = new FileWriter(txt,true);
		PrintWriter pw = new PrintWriter(fw);
                
                
		NomeCompleto = this.Nome+" "+this.Sobrenome;
		pw.println(this.Nome+" "+this.Sobrenome);
                
               
		
		
                pw.flush();
		pw.close();
		fw.close();
		
		} catch (IOException ex){
			Logger.getLogger(getNome()).log(Level.SEVERE, null, ex);
		}
		return "Pessoa Cadastrada";
	}
        
        public String SalvarSala(){
            try{
                File txt = new File("TreinamentoCadastroSala.txt");
		FileWriter fw = new FileWriter(txt,true);
		PrintWriter pw = new PrintWriter(fw);
                pw.println(this.SalaNome);
                pw.println("Lotação de "+this.Lotacao);
                
                pw.println();
                
                pw.flush();
		pw.close();
		fw.close();
		
		} catch (IOException ex){
			Logger.getLogger(getNomeCompleto()).log(Level.SEVERE, null, ex);
		}
		return "Sala de Evento cadastrada";
       
            
            
            
        }
        public String SalvarCafe(){
             try{
		File txt = new File("CadastroCafe.txt");
		FileWriter fw = new FileWriter(txt,true);
		PrintWriter pw = new PrintWriter(fw);
                
                pw.println(this.CafeNome);
                pw.println("Lotação de "+this.CafeLote);
                
                pw.flush();
                pw.close();
                fw.close();
		
		} catch (IOException ex){
                    ex.printStackTrace();

		}
		return "Sala de Café cadastrada";
        }
        
        //metodos que serve como intermediario com os metodos chamada de texto e entrada da informação para fazer a chamada
        public void trocaPesquisaPessoa(){
           String NomePessoa = JOptionPane.showInputDialog("Informe o nome completo da pessoa, para verficar se ela esta participando do evento");
         
           String arq =("CadastroPessoa.txt");
           match(NomePessoa,arq);
           
           
    }
        
        public void trocaPesquisaCafe(){
           String NomeCafe = JOptionPane.showInputDialog("Informe do espaço de coffe break, para verficar se ela existe nesse evento");
         
           String arq =("CadastroCafe.txt");
           match(NomeCafe,arq);
           
           
    }
        
        public void trocaPesquisaSala(){
           String NomeSala = JOptionPane.showInputDialog("Informe o nome da Sala, para verficar se ela existe no evento");
         
           String arq =("TreinamentoCadastroSala.txt");
           match(NomeSala,arq);
           
           
    }

   
}
